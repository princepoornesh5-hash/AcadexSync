import 'package:dio/dio.dart';
import '../../domain/repositories/ai_repository.dart';
import '../../../../core/network/api_client.dart';

class ApiAiRepository implements AiRepository {
  final ApiClient _client;

  ApiAiRepository({ApiClient? client}) : _client = client ?? apiClient;

  @override
  Future<String> sendMessage({
    required String query,
    required Map<String, dynamic> context,
  }) async {
    try {
      final response = await _client.dio.post(
        '/ai/chat',
        data: {
          'message': query.trim(),
        },
      );

      final data = response.data;
      if (data is Map<String, dynamic>) {
        final innerData = data['data'];
        if (innerData is Map<String, dynamic> && innerData['answer'] != null) {
          return innerData['answer'] as String;
        }
        if (data['answer'] != null) {
          return data['answer'] as String;
        }
      }

      return "No answer received from ACADEX AI Assistant.";
    } on DioException catch (dioError) {
      final statusCode = dioError.response?.statusCode;

      if (statusCode == 401) {
        throw Exception('Session expired. Please log in again.');
      } else if (statusCode == 403) {
        throw Exception('Access denied. You do not have permission to access this resource.');
      } else if (statusCode == 429) {
        throw Exception('Too many requests. Please wait a moment before sending another message.');
      } else if (statusCode == 503) {
        final errorData = dioError.response?.data;
        if (errorData is Map && errorData['error'] is Map && errorData['error']['message'] != null) {
          throw Exception(errorData['error']['message']);
        }
        throw Exception('AI Assistant service is not configured on the server.');
      } else if (statusCode == 504) {
        throw Exception('AI Assistant timed out waiting for upstream response. Please try again.');
      } else if (dioError.type == DioExceptionType.connectionTimeout ||
                 dioError.type == DioExceptionType.receiveTimeout ||
                 dioError.type == DioExceptionType.connectionError) {
        throw Exception('Network connection failure. Please check your internet connection.');
      }

      final errorData = dioError.response?.data;
      if (errorData is Map && errorData['error'] is Map && errorData['error']['message'] != null) {
        throw Exception(errorData['error']['message']);
      }

      throw Exception('Acadex AI is temporarily unavailable.');
    } catch (_) {
      throw Exception('Acadex AI is temporarily unavailable.');
    }
  }
}
