import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../../../app/theme/app_theme.dart';
import '../../domain/models/notification_models.dart';
import '../coordinators/notification_navigation_coordinator.dart';

class NotificationCard extends ConsumerWidget {
  final NotificationModel notification;
  final VoidCallback onReadToggle;
  final VoidCallback onDelete;

  const NotificationCard({
    super.key,
    required this.notification,
    required this.onReadToggle,
    required this.onDelete,
  });

  String _formatRelativeTime(DateTime time) {
    final now = DateTime.now();
    final difference = now.difference(time);

    if (difference.inMinutes < 1) return 'Just now';
    if (difference.inMinutes < 60) return '${difference.inMinutes}m ago';
    if (difference.inHours < 24) return '${difference.inHours}h ago';
    if (difference.inDays == 1) return 'Yesterday';
    if (difference.inDays < 7) return '${difference.inDays}d ago';
    
    return '${time.day}/${time.month}/${time.year}';
  }

  IconData _getIconForCategory(NotificationCategory category) {
    if (category == NotificationCategory.attendance) {
      if (notification.notificationType == NotificationType.attendanceAbsent) return LucideIcons.userX;
      if (notification.notificationType == NotificationType.attendanceAlert || notification.priority == NotificationPriority.critical) return LucideIcons.shieldAlert;
      if (notification.notificationType == NotificationType.attendanceLow) return LucideIcons.alertTriangle;
      final titleLower = notification.title.toLowerCase();
      if (titleLower.contains('recovered')) return LucideIcons.circleCheck;
      if (titleLower.contains('drop')) return LucideIcons.trendingDown;
      if (titleLower.contains('absence') || titleLower.contains('absent')) return LucideIcons.userX;
      if (titleLower.contains('unmarked') || titleLower.contains('missing')) return LucideIcons.calendarX;
      if (notification.priority == NotificationPriority.critical) return LucideIcons.shieldAlert;
      return LucideIcons.calendarCheck;
    }

    switch (category) {
      case NotificationCategory.request:
        if (notification.notificationType == NotificationType.requestApproved) {
          return LucideIcons.checkCircle;
        } else if (notification.notificationType == NotificationType.requestRejected) {
          return LucideIcons.xCircle;
        } else if (notification.notificationType == NotificationType.requestReceived) {
          return LucideIcons.inbox;
        }
        return LucideIcons.fileCheck2;
      case NotificationCategory.attendance: return LucideIcons.calendarCheck;
      case NotificationCategory.academic: return LucideIcons.bookOpen;
      case NotificationCategory.system: return LucideIcons.settings;
      case NotificationCategory.profile: return LucideIcons.user;
      case NotificationCategory.security: return LucideIcons.shieldAlert;
      case NotificationCategory.notes: return LucideIcons.fileText;
      case NotificationCategory.certificates: return LucideIcons.award;
      case NotificationCategory.timetable: return LucideIcons.calendarDays;
      case NotificationCategory.announcement: return LucideIcons.megaphone;
      case NotificationCategory.assignment: return LucideIcons.bookMarked;
      case NotificationCategory.practical: return LucideIcons.flaskConical;
      case NotificationCategory.assessment: return LucideIcons.clipboardCheck;
      case NotificationCategory.result: return LucideIcons.graduationCap;
      case NotificationCategory.calendar: return LucideIcons.calendar;
      case NotificationCategory.general: return LucideIcons.bell;
    }
  }

  Color _getColorForPriority(BuildContext context, NotificationPriority priority) {
    if (notification.category == NotificationCategory.attendance &&
        notification.title.toLowerCase().contains('recovered')) {
      return AcadexColors.success;
    }
    if (notification.category == NotificationCategory.request) {
      if (notification.notificationType == NotificationType.requestApproved) {
        return AcadexColors.success;
      } else if (notification.notificationType == NotificationType.requestRejected) {
        return AcadexColors.error;
      }
    }
    switch (priority) {
      case NotificationPriority.critical: return AcadexColors.error;
      case NotificationPriority.high: return AcadexColors.warning;
      case NotificationPriority.normal: return Theme.of(context).primaryColor;
      case NotificationPriority.low: return Theme.of(context).textTheme.bodySmall?.color ?? AcadexColors.inkMuted;
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isUnread = !notification.isRead;
    final iconColor = _getColorForPriority(context, notification.priority);
    final bgColor = Theme.of(context).colorScheme.surface;

    return Dismissible(
      key: Key(notification.id),
      direction: DismissDirection.endToStart,
      onDismissed: (_) => onDelete(),
      background: Container(
        alignment: Alignment.centerRight,
        padding: const EdgeInsets.only(right: 24),
        color: AcadexColors.error,
        child: const Icon(LucideIcons.trash2, color: Colors.white),
      ),
      child: InkWell(
        onTap: () {
          if (isUnread) onReadToggle();
          ref.read(notificationNavigationCoordinatorProvider).handleNotificationTap(context, notification);
        },
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: bgColor,
            border: Border(bottom: BorderSide(color: Theme.of(context).dividerColor)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Icon
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: iconColor.withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  _getIconForCategory(notification.category),
                  color: iconColor,
                  size: 20,
                ),
              ),
              const SizedBox(width: 16),
              
              // Content
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            notification.title,
                            style: AcadexTypography.body(
                              color: isUnread ? AcadexColors.ink : AcadexColors.inkSecondary,
                            ).copyWith(
                              fontWeight: isUnread ? FontWeight.w700 : FontWeight.w600,
                            ),
                          ),
                        ),
                        Text(
                          _formatRelativeTime(notification.timestamp),
                          style: AcadexTypography.caption(color: AcadexColors.inkMuted),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Text(
                      notification.message,
                      style: AcadexTypography.bodySmall(color: AcadexColors.inkSecondary),
                    ),
                    if (notification.collegeId != null || notification.audienceType == NotificationAudienceType.platform) ...[
                      const SizedBox(height: 6),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: notification.collegeId != null
                                  ? AcadexColors.primary.withValues(alpha: 0.1)
                                  : Colors.amber.withValues(alpha: 0.15),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Icon(
                                  notification.collegeId != null ? LucideIcons.building2 : LucideIcons.globe,
                                  size: 11,
                                  color: notification.collegeId != null ? AcadexColors.primary : Colors.amber.shade800,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  notification.collegeId != null ? 'Campus Workspace' : 'Global Platform',
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontWeight: FontWeight.w600,
                                    color: notification.collegeId != null ? AcadexColors.primary : Colors.amber.shade900,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ],
                    if (notification.navigationTarget != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Row(
                          children: [
                            Text(
                              'View details',
                              style: AcadexTypography.caption(color: AcadexColors.primary).copyWith(fontWeight: FontWeight.w600),
                            ),
                            const SizedBox(width: 4),
                            const Icon(LucideIcons.chevronRight, size: 14, color: AcadexColors.primary),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              
              // Unread Dot
              if (isUnread)
                Padding(
                  padding: const EdgeInsets.only(left: 12, top: 8),
                  child: Container(
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: Theme.of(context).primaryColor,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
