import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:lucide_icons_flutter/lucide_icons.dart';
import '../../../../app/theme/app_theme.dart';
import '../../domain/models/activity_item_model.dart';
import '../../domain/models/dashboard_stat_model.dart';
import '../../domain/models/quick_action_model.dart';
import '../../../attendance/domain/models/assigned_class.dart';
import '../../../attendance/presentation/providers/attendance_providers.dart';
import '../../../auth/domain/models/auth_state.dart';
import '../../../auth/presentation/providers/auth_provider.dart';
import '../../../academic_structure/presentation/providers/academic_providers.dart';
import '../../../timetable/presentation/providers/timetable_providers.dart';
import '../../../notes/presentation/providers/notes_providers.dart';
import '../../../notifications/presentation/providers/notification_providers.dart';
import '../../data/repositories/dashboard_repository.dart';
import '../../domain/models/home_dashboard_models.dart';

// ── Canonical Home Dashboard Provider (Prompt 49) ───────────────────────────

final dashboardRepositoryProvider = Provider<DashboardRepository>((ref) {
  return DashboardRepository();
});

final homeDashboardProvider = FutureProvider.autoDispose<HomeDashboardModel>((ref) async {
  final repo = ref.watch(dashboardRepositoryProvider);
  return repo.getHomeDashboard();
});

// ── Super Admin (Platform Owner) ──────────────────────────────────────────────

final superAdminStatsProvider = FutureProvider.autoDispose<List<DashboardStatModel>>((ref) async {
  final repo = ref.watch(attendanceRepoProvider);
  final summary = await repo.getSuperAdminSummary();

  return [
    DashboardStatModel(
      title: 'Total Colleges',
      value: '${summary.totalColleges}',
      subtitle: 'Registered institutions',
      icon: LucideIcons.building,
      iconColor: DashboardColors.primary,
      iconBackground: DashboardColors.primaryLight,
    ),
    DashboardStatModel(
      title: 'College Admins',
      value: '${summary.totalCollegeAdmins > 0 ? summary.totalCollegeAdmins : summary.totalColleges}',
      subtitle: 'Active administrators',
      icon: LucideIcons.userCheck,
      iconColor: DashboardColors.purple,
      iconBackground: DashboardColors.purpleLight,
    ),
    DashboardStatModel(
      title: 'Total Faculty',
      value: '${summary.totalFaculty}',
      subtitle: 'Active faculty members',
      icon: LucideIcons.users,
      iconColor: DashboardColors.teal,
      iconBackground: DashboardColors.tealLight,
    ),
    DashboardStatModel(
      title: 'Total Students',
      value: '${summary.totalStudents}',
      subtitle: 'Enrolled students',
      icon: LucideIcons.graduationCap,
      iconColor: DashboardColors.success,
      iconBackground: DashboardColors.successLight,
    ),
    DashboardStatModel(
      title: 'Global Attendance',
      value: '${summary.todayAttendancePercentage.toStringAsFixed(1)}%',
      subtitle: 'Platform-wide average',
      icon: LucideIcons.clipboardCheck,
      iconColor: DashboardColors.warning,
      iconBackground: DashboardColors.warningLight,
    ),
    DashboardStatModel(
      title: 'Platform Activity',
      value: '${summary.totalColleges + summary.totalDepartments} units',
      subtitle: 'Active academic units',
      icon: LucideIcons.activity,
      iconColor: DashboardColors.primary,
      iconBackground: DashboardColors.primaryLight,
    ),
  ];
});

final superAdminQuickActionsProvider = Provider<List<QuickActionModel>>((ref) => [
      const QuickActionModel(
        label: 'Add College',
        icon: LucideIcons.building,
        iconColor: DashboardColors.primary,
        iconBackground: DashboardColors.primaryLight,
        route: '/academics/colleges/new',
      ),
      const QuickActionModel(
        label: 'Create User',
        icon: LucideIcons.userPlus,
        iconColor: DashboardColors.purple,
        iconBackground: DashboardColors.purpleLight,
        route: '/users/new',
      ),
      const QuickActionModel(
        label: 'Manage Users',
        icon: LucideIcons.users,
        iconColor: DashboardColors.teal,
        iconBackground: DashboardColors.tealLight,
        route: '/users',
      ),
      const QuickActionModel(
        label: 'View Reports',
        icon: LucideIcons.barChart3,
        iconColor: DashboardColors.warning,
        iconBackground: DashboardColors.warningLight,
        route: '/analytics',
      ),
      const QuickActionModel(
        label: 'Audit Logs',
        icon: LucideIcons.shieldCheck,
        iconColor: DashboardColors.success,
        iconBackground: DashboardColors.successLight,
        route: '/settings',
      ),
    ]);

final superAdminActivityProvider = FutureProvider.autoDispose<List<ActivityItemModel>>((ref) async {
  final notifsAsync = ref.watch(notificationsProvider);
  final notifs = notifsAsync.value ?? [];
  if (notifs.isEmpty) return [];

  return notifs.take(5).map((n) {
    return ActivityItemModel(
      title: n.title,
      subtitle: n.message,
      timeAgo: _formatTimeAgo(n.timestamp),
      icon: LucideIcons.bell,
      iconColor: DashboardColors.primary,
      iconBackground: DashboardColors.primaryLight,
    );
  }).toList();
});

// ── College Admin (College Operational Authority) ─────────────────────────────

final collegeAdminStatsProvider = FutureProvider.autoDispose<List<DashboardStatModel>>((ref) async {
  final repo = ref.watch(attendanceRepoProvider);
  final summary = await repo.getCollegeSummary();
  final subjects = ref.watch(subjectsProvider).valueOrNull ?? [];
  final years = ref.watch(academicYearsProvider).valueOrNull ?? [];
  final activeYear = years.where((y) => y.isCurrent || y.status == 'active').firstOrNull;

  return [
    DashboardStatModel(
      title: 'Departments',
      value: '${summary.totalDepartments}',
      subtitle: 'Active departments',
      icon: LucideIcons.layoutGrid,
      iconColor: DashboardColors.primary,
      iconBackground: DashboardColors.primaryLight,
    ),
    DashboardStatModel(
      title: 'Faculty',
      value: '${summary.totalFaculty}',
      subtitle: 'Teaching staff',
      icon: LucideIcons.userCheck,
      iconColor: DashboardColors.purple,
      iconBackground: DashboardColors.purpleLight,
    ),
    DashboardStatModel(
      title: 'Students',
      value: '${summary.totalStudents}',
      subtitle: 'Enrolled across depts',
      icon: LucideIcons.users,
      iconColor: DashboardColors.success,
      iconBackground: DashboardColors.successLight,
    ),
    DashboardStatModel(
      title: 'Attendance',
      value: '${summary.todayAttendancePercentage.toStringAsFixed(1)}%',
      subtitle: 'College-wide metric',
      icon: LucideIcons.clipboardCheck,
      iconColor: DashboardColors.warning,
      iconBackground: DashboardColors.warningLight,
    ),
    DashboardStatModel(
      title: 'Subjects',
      value: '${subjects.length}',
      subtitle: 'Curriculum offerings',
      icon: LucideIcons.bookOpen,
      iconColor: DashboardColors.teal,
      iconBackground: DashboardColors.tealLight,
    ),
    DashboardStatModel(
      title: 'Academic Year',
      value: activeYear?.name ?? 'Active',
      subtitle: 'Current cycle',
      icon: LucideIcons.calendar,
      iconColor: DashboardColors.primary,
      iconBackground: DashboardColors.primaryLight,
    ),
  ];
});

final collegeAdminQuickActionsProvider = Provider<List<QuickActionModel>>((ref) => [
      const QuickActionModel(
        label: 'Department Setup',
        icon: LucideIcons.compass,
        iconColor: DashboardColors.primary,
        iconBackground: DashboardColors.primaryLight,
        route: '/academics/setup',
      ),
      const QuickActionModel(
        label: 'Academic Years',
        icon: LucideIcons.calendarDays,
        iconColor: DashboardColors.primary,
        iconBackground: DashboardColors.primaryLight,
        route: '/academics/academic-years',
      ),
      const QuickActionModel(
        label: 'Departments',
        icon: LucideIcons.building2,
        iconColor: DashboardColors.purple,
        iconBackground: DashboardColors.purpleLight,
        route: '/academics/departments',
      ),
      const QuickActionModel(
        label: 'Assign HODs',
        icon: LucideIcons.userCheck,
        iconColor: DashboardColors.teal,
        iconBackground: DashboardColors.tealLight,
        route: '/academics/hods',
      ),
      const QuickActionModel(
        label: 'College Analytics',
        icon: LucideIcons.barChart3,
        iconColor: DashboardColors.success,
        iconBackground: DashboardColors.successLight,
        route: '/analytics',
      ),
    ]);

final collegeAdminActivityProvider = FutureProvider.autoDispose<List<ActivityItemModel>>((ref) async {
  final notifsAsync = ref.watch(notificationsProvider);
  final notifs = notifsAsync.value ?? [];
  if (notifs.isEmpty) return [];

  return notifs.take(5).map((n) {
    return ActivityItemModel(
      title: n.title,
      subtitle: n.message,
      timeAgo: _formatTimeAgo(n.timestamp),
      icon: LucideIcons.bell,
      iconColor: DashboardColors.primary,
      iconBackground: DashboardColors.primaryLight,
    );
  }).toList();
});

// ── HOD (Department Operational Authority) ────────────────────────────────────

final hodStatsProvider = FutureProvider.autoDispose<List<DashboardStatModel>>((ref) async {
  final authState = ref.watch(authProvider);
  final departmentId = authState is AuthAuthenticated ? (authState.user.departmentId ?? '') : '';

  final repo = ref.watch(attendanceRepoProvider);
  final academicRepo = ref.watch(academicRepositoryProvider);

  final summary = departmentId.isNotEmpty
      ? await repo.getDepartmentSummary(departmentId)
      : null;

  // Canonical Faculty source: directly from academicRepository (identical to Faculty Management page)
  final facultyList = departmentId.isNotEmpty
      ? await academicRepo.getFaculty(departmentId: departmentId)
      : await academicRepo.getFaculty();
  final facultyCount = facultyList.isNotEmpty ? facultyList.length : (summary?.totalFaculty ?? 0);

  // Student count: from summary or academicRepo
  final studentsCount = (summary?.totalStudents ?? 0) > 0
      ? summary!.totalStudents
      : (departmentId.isNotEmpty
          ? (await academicRepo.getStudents(departmentId: departmentId)).length
          : 0);

  final subjects = ref.watch(subjectsProvider).valueOrNull ?? [];
  final subjectsCount = subjects.where((s) => departmentId.isEmpty || s.departmentId == departmentId).length;

  return [
    DashboardStatModel(
      title: 'Department Faculty',
      value: '$facultyCount',
      subtitle: 'In your department',
      icon: LucideIcons.userCheck,
      iconColor: DashboardColors.purple,
      iconBackground: DashboardColors.purpleLight,
    ),
    DashboardStatModel(
      title: 'Department Students',
      value: '$studentsCount',
      subtitle: 'Enrolled this semester',
      icon: LucideIcons.users,
      iconColor: DashboardColors.primary,
      iconBackground: DashboardColors.primaryLight,
    ),
    DashboardStatModel(
      title: 'Department Subjects',
      value: '$subjectsCount',
      subtitle: 'Active curriculum',
      icon: LucideIcons.bookOpen,
      iconColor: DashboardColors.teal,
      iconBackground: DashboardColors.tealLight,
    ),
    DashboardStatModel(
      title: 'Department Attendance',
      value: '${(summary?.overallPercentage ?? 0.0).toStringAsFixed(1)}%',
      subtitle: 'Department average',
      icon: LucideIcons.clipboardCheck,
      iconColor: DashboardColors.warning,
      iconBackground: DashboardColors.warningLight,
    ),
  ];
});

final hodQuickActionsProvider = Provider<List<QuickActionModel>>((ref) => [
      const QuickActionModel(
        label: 'Continue Setup',
        icon: LucideIcons.compass,
        iconColor: DashboardColors.primary,
        iconBackground: DashboardColors.primaryLight,
        route: '/academics/setup',
      ),
      const QuickActionModel(
        label: 'Assign Faculty',
        icon: LucideIcons.briefcase,
        iconColor: DashboardColors.purple,
        iconBackground: DashboardColors.purpleLight,
        route: '/faculty-assignments',
      ),
      const QuickActionModel(
        label: 'Upload Note',
        icon: LucideIcons.filePlus,
        iconColor: DashboardColors.teal,
        iconBackground: DashboardColors.tealLight,
        route: '/notes/new',
      ),
      const QuickActionModel(
        label: 'Department Analytics',
        icon: LucideIcons.barChart3,
        iconColor: DashboardColors.warning,
        iconBackground: DashboardColors.warningLight,
        route: '/analytics',
      ),
    ]);

final hodActivityProvider = FutureProvider.autoDispose<List<ActivityItemModel>>((ref) async {
  final notifsAsync = ref.watch(notificationsProvider);
  final notifs = notifsAsync.value ?? [];
  if (notifs.isEmpty) return [];

  return notifs.take(5).map((n) {
    return ActivityItemModel(
      title: n.title,
      subtitle: n.message,
      timeAgo: _formatTimeAgo(n.timestamp),
      icon: LucideIcons.bell,
      iconColor: DashboardColors.primary,
      iconBackground: DashboardColors.primaryLight,
    );
  }).toList();
});

// ── Faculty (Teaching Operations Workspace) ───────────────────────────────────

final facultyStatsProvider = FutureProvider.autoDispose<List<DashboardStatModel>>((ref) async {
  final assignments = ref.watch(myFacultyAssignmentsProvider);
  final repo = ref.watch(attendanceRepoProvider);
  final authState = ref.watch(authProvider);
  final currentUserId = authState is AuthAuthenticated ? authState.user.id : '';
  
  final classes = currentUserId.isNotEmpty
      ? await repo.getAssignedClasses(currentUserId, DateTime.now()).catchError((_) => <AssignedClass>[])
      : <AssignedClass>[];
  final uniqueSubjects = assignments.map((a) => a.subjectId).toSet().length;
  final uniqueSections = assignments.map((a) => a.sectionId).toSet().length;

  final sections = ref.watch(sectionsProvider).valueOrNull ?? [];
  final assignedSectionIds = assignments.map((a) => a.sectionId).toSet();
  final assignedStudentsCount = sections
      .where((s) => assignedSectionIds.contains(s.id))
      .fold<int>(0, (sum, s) => sum + (s.capacity > 0 ? s.capacity : 0));

  return [
    DashboardStatModel(
      title: 'My Subjects',
      value: '$uniqueSubjects',
      subtitle: 'Assigned courses',
      icon: LucideIcons.bookOpen,
      iconColor: DashboardColors.primary,
      iconBackground: DashboardColors.primaryLight,
    ),
    DashboardStatModel(
      title: "Today's Classes",
      value: '${classes.length}',
      subtitle: 'Active classes',
      icon: LucideIcons.clock,
      iconColor: DashboardColors.success,
      iconBackground: DashboardColors.successLight,
    ),
    DashboardStatModel(
      title: 'My Sections',
      value: '$uniqueSections',
      subtitle: 'Assigned sections',
      icon: LucideIcons.layoutGrid,
      iconColor: DashboardColors.warning,
      iconBackground: DashboardColors.warningLight,
    ),
    DashboardStatModel(
      title: 'Assigned Students',
      value: '$assignedStudentsCount',
      subtitle: 'Across assigned classes',
      icon: LucideIcons.users,
      iconColor: DashboardColors.purple,
      iconBackground: DashboardColors.purpleLight,
    ),
  ];
});

final facultyQuickActionsProvider = Provider<List<QuickActionModel>>((ref) => [
      const QuickActionModel(
        label: 'Mark Attendance',
        icon: LucideIcons.clipboardCheck,
        iconColor: DashboardColors.teal,
        iconBackground: DashboardColors.tealLight,
        route: '/attendance',
      ),
      const QuickActionModel(
        label: 'My Classes',
        icon: LucideIcons.bookOpen,
        iconColor: DashboardColors.primary,
        iconBackground: DashboardColors.primaryLight,
        route: '/my-assignments',
      ),
      const QuickActionModel(
        label: 'Upload Note',
        icon: LucideIcons.filePlus,
        iconColor: DashboardColors.purple,
        iconBackground: DashboardColors.purpleLight,
        route: '/notes/new',
      ),
      const QuickActionModel(
        label: 'Assignments',
        icon: LucideIcons.fileSpreadsheet,
        iconColor: DashboardColors.success,
        iconBackground: DashboardColors.successLight,
        route: '/assignments',
      ),
      const QuickActionModel(
        label: "Today's Timetable",
        icon: LucideIcons.calendarDays,
        iconColor: DashboardColors.warning,
        iconBackground: DashboardColors.warningLight,
        route: '/timetable',
      ),
    ]);

final facultyActivityProvider = FutureProvider.autoDispose<List<ActivityItemModel>>((ref) async {
  final notifsAsync = ref.watch(notificationsProvider);
  final notifs = notifsAsync.value ?? [];
  if (notifs.isEmpty) return [];

  return notifs.take(5).map((n) {
    return ActivityItemModel(
      title: n.title,
      subtitle: n.message,
      timeAgo: _formatTimeAgo(n.timestamp),
      icon: LucideIcons.bell,
      iconColor: DashboardColors.primary,
      iconBackground: DashboardColors.primaryLight,
    );
  }).toList();
});

// ── Student (Academic Hub) ───────────────────────────────────────────────────

final studentStatsProvider = FutureProvider.autoDispose<List<DashboardStatModel>>((ref) async {
  final profile = await ref.watch(currentStudentAcademicProfileProvider.future).catchError((_) => null);
  final schedule = ref.watch(todayScheduleProvider).value ?? [];
  final notes = ref.watch(userNotesProvider).value ?? [];

  final attPercentage = profile?.overallAttendancePercentage ?? 0.0;
  final enrolledSubs = profile?.enrolledSubjects.length ?? 0;
  final notesCount = notes.length;
  final todayClasses = schedule.length;

  return [
    DashboardStatModel(
      title: 'Overall Attendance',
      value: '${attPercentage.toStringAsFixed(1)}%',
      subtitle: attPercentage >= 75 ? 'Good standing' : (attPercentage > 0 ? 'Low attendance alert' : 'No records yet'),
      icon: LucideIcons.clipboardCheck,
      iconColor: attPercentage >= 75 ? DashboardColors.success : (attPercentage > 0 ? DashboardColors.warning : DashboardColors.textSecondary),
      iconBackground: attPercentage >= 75 ? DashboardColors.successLight : (attPercentage > 0 ? DashboardColors.warningLight : DashboardColors.divider),
    ),
    DashboardStatModel(
      title: "Today's Classes",
      value: '$todayClasses',
      subtitle: todayClasses > 0 ? '$todayClasses scheduled' : 'No classes today',
      icon: LucideIcons.clock,
      iconColor: DashboardColors.primary,
      iconBackground: DashboardColors.primaryLight,
    ),
    DashboardStatModel(
      title: 'Subjects',
      value: '$enrolledSubs',
      subtitle: 'Enrolled courses',
      icon: LucideIcons.bookOpen,
      iconColor: DashboardColors.purple,
      iconBackground: DashboardColors.purpleLight,
    ),
    DashboardStatModel(
      title: 'New Notes',
      value: '$notesCount',
      subtitle: 'Study materials',
      icon: LucideIcons.fileText,
      iconColor: DashboardColors.teal,
      iconBackground: DashboardColors.tealLight,
    ),
  ];
});

final studentQuickActionsProvider = Provider<List<QuickActionModel>>((ref) => [
      const QuickActionModel(
        label: 'My Schedule',
        icon: LucideIcons.calendarDays,
        iconColor: DashboardColors.purple,
        iconBackground: DashboardColors.purpleLight,
        route: '/timetable',
      ),
      const QuickActionModel(
        label: 'Attendance History',
        icon: LucideIcons.clipboardCheck,
        iconColor: DashboardColors.primary,
        iconBackground: DashboardColors.primaryLight,
        route: '/attendance',
      ),
      const QuickActionModel(
        label: 'Study Materials',
        icon: LucideIcons.fileText,
        iconColor: DashboardColors.teal,
        iconBackground: DashboardColors.tealLight,
        route: '/notes',
      ),
      const QuickActionModel(
        label: 'Course Syllabus',
        icon: LucideIcons.bookOpen,
        iconColor: DashboardColors.warning,
        iconBackground: DashboardColors.warningLight,
        route: '/academics/subjects',
      ),
    ]);

final studentActivityProvider = FutureProvider.autoDispose<List<ActivityItemModel>>((ref) async {
  final notifsAsync = ref.watch(notificationsProvider);
  final notifs = notifsAsync.value ?? [];
  if (notifs.isEmpty) return [];

  return notifs.take(5).map((n) {
    return ActivityItemModel(
      title: n.title,
      subtitle: n.message,
      timeAgo: _formatTimeAgo(n.timestamp),
      icon: LucideIcons.bell,
      iconColor: DashboardColors.primary,
      iconBackground: DashboardColors.primaryLight,
    );
  }).toList();
});

String _formatTimeAgo(DateTime dt) {
  final diff = DateTime.now().difference(dt);
  if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
  if (diff.inHours < 24) return '${diff.inHours}h ago';
  if (diff.inDays == 1) return 'Yesterday';
  return '${diff.inDays}d ago';
}
