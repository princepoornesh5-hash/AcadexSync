# AcadexSync Open Architectural Questions & Unresolved Details

This document outlines architectural ambiguities, operational configurations, and product roadmap decisions that cannot be definitively established from source-code inspection alone.

---

## 1. Microservice Deployment Topology & Gateway Routing

### Context
- The codebase contains two distinct backend implementations:
  1. The primary **Node.js + TypeScript Backend** (`backend/src/`), exposing `/api/v1/*` including `/api/v1/ai/chat` powered by Google Gemini 2.5 Flash via `@google/genai`.
  2. A specialized **Python FastAPI Microservice** (`backend/ai_service/`), exposing `/api/v1/ai/chat` (FAISS RAG) and `/api/v1/ai/generate-timetable`.
- In `frontend/lib/core/network/api_client.dart`:
  - `defaultBaseUrl` defaults to port `5050` (Node.js).
  - `defaultAiUrl` in development defaults to port `5001` (Python microservice), but in production release resolves to `https://acadex-backend-main.onrender.com/api/v1/ai` (Node.js).

### Open Questions
1. **Target Production Hosting**: Are the Node.js API server and Python AI microservice deployed as independent services on Render/AWS ECS, or is the Python microservice an optional local development tool?
2. **Reverse Proxy vs Direct Ingestion**: If both run in production, does the Node.js backend reverse-proxy `/api/v1/ai/*` requests to the Python microservice, or does the client maintain two separate Dio HTTP clients?

---

## 2. Firebase Deprecation Cut-Off Timeline

### Context
- The backend has been completely engineered on Node.js, Express, and MongoDB Atlas with 48 Mongoose schemas and native JWT authentication.
- However, `frontend/pubspec.yaml` still imports `cloud_firestore`, `firebase_auth`, `firebase_storage`, and `cloud_functions`.
- A few transitional files (e.g. `frontend/lib/firebase_options.dart` and legacy test suites) still reference Firebase client initialization.

### Open Questions
1. **Sunset Schedule**: When will the remaining Firebase client dependencies be removed from `pubspec.yaml` to reduce binary size and eliminate dual-backend confusion?
2. **Push Notifications Exemption**: Will `firebase_messaging` (FCM) remain permanently for mobile push notifications while all database and auth operations transfer 100% to MongoDB Atlas?

---

## 3. Production AI Quota, Tier & Fallback Planning

### Context
- `backend/src/services/ai.service.ts` integrates `@google/genai` with `gemini-2.5-flash`.
- A rate limit of 30 requests per minute is configured (`AI_RATE_LIMIT_MAX=30`).

### Open Questions
1. **Institutional Quota Scaling**: For an institution with 5,000 concurrent students asking study questions during exam weeks, what is the allocated Google Cloud Vertex AI / Gemini API tier?
2. **Provider Redundancy**: If the Google Gemini upstream API encounters regional downtime or rate limit exhaustion, is a fallback model planned (e.g. secondary API key, Anthropic Claude, or local Ollama instance)?

---

## 4. Multi-Tenant Database Sharding & Archival Strategy

### Context
- The system enforces multi-tenancy via `collegeId` on every collection.
- High-frequency collections (`AttendanceRecord`, `AttendanceSession`, `AuditLog`, `Notification`) grow rapidly: an institution with 5,000 students generates ~100,000 attendance records per month.

### Open Questions
1. **MongoDB Atlas Sharding Key**: What is the planned sharding key for multi-campus scaling? (`{ collegeId: 1, _id: 1 }` or `{ collegeId: 1, academicYearId: 1 }`?)
2. **Cold Data Archival**: After an academic year concludes and is marked `archived`, is historical attendance moved to secondary cold collections or preserved in the primary operational cluster?

---

## 5. Media & Document Lifecycle Governance in ImageKit

### Context
- Lecture notes, assignment file submissions, and profile pictures are uploaded to ImageKit via `imagekit.service.ts` and delivered via signed URLs.

### Open Questions
1. **Storage Retention**: What is the retention policy for past student coursework submissions? Are submissions from prior academic years retained indefinitely, or purged/compressed after graduation?
2. **Bandwidth Quotas**: Does each tenant college have isolated storage bucket quotas, or are all institutions aggregated under a single ImageKit enterprise master account?

---

## 6. Hardware Terminal & Biometric Ingestion Roadmap

### Context
- Attendance roll-calls currently operate through faculty mobile/web interfaces with roll numbers and toggle buttons.
- Some institutional roadmaps mention biometric fingerprint/facial recognition terminals.

### Open Questions
1. **Hardware Protocol**: If physical biometric devices are deployed, what ingestion protocol is planned (e.g. network edge gateway pushing to `/api/v1/attendance/biometric-sync`)?
2. **Audit & Dispute Resolution**: How will biometric verification logs interface with the existing manual roll-call dispute resolution workflow?
