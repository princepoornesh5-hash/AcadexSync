# AcadexSync Data Model & Canonical Schema Reference

This document provides an exhaustive reference of the data model powering **AcadexSync**, detailing the 48 canonical Mongoose schemas, primary keys, relationships, indexing strategies, and synthetic seed structures.

---

## 1. Identity & Multi-Tenancy Principles

1. **Decoupled Identity Model**:
   - Technical Primary Key (`_id`): A 12-byte MongoDB `ObjectId` generated automatically. Serves as the immutable relational foreign key across all database collections.
   - Institutional Business Identifier (`instituteId`): A human-readable, indexed business string (e.g. `CSE-2026-042`, `FAC-MATH-012`). Unique within the platform, editable by administrators without invalidating foreign key relationships.
2. **Strict Multi-Tenant Scoping**:
   - Every institutional entity is scoped via `collegeId: { type: Schema.Types.ObjectId, ref: 'College', required: true }`.
   - Compound indexes ensure unique constraints are scoped per college (e.g. `{ collegeId: 1, code: 1 }`).

---

## 2. Core Academic Structure Entities

### 2.1 `College` (Root Tenant Container)
- **Purpose**: Defines the institutional boundary for all downstream departments, users, and academic operations.
- **Key Fields**:
  - `_id`: ObjectId (Canonical ID)
  - `name`: String (e.g. "Sri Venkateswara Government Polytechnic")
  - `code`: String (Unique, e.g. "SVGP", "KIT")
  - `status`: String enum (`'active'`, `'inactive'`)
  - `logoUrl`: String (Optional ImageKit URL)
  - `address`: Embedded object (street, city, state, postalCode)
  - `settings`: Embedded configuration settings
- **Indexes**: `{ code: 1 }` (unique), `{ status: 1 }`

### 2.2 `Department` (Academic Division)
- **Purpose**: Academic division governing courses, faculty, and subject curricula.
- **Key Fields**:
  - `_id`: ObjectId
  - `collegeId`: ObjectId (ref: `College`, required)
  - `name`: String (e.g. "Computer Engineering")
  - `code`: String (e.g. "CME", "ECE", "MECH")
  - `hodId`: ObjectId (ref: `User`, optional HOD reference)
  - `status`: String enum (`'active'`, `'inactive'`)
- **Indexes**: `{ collegeId: 1, code: 1 }` (unique compound)

### 2.3 `Course` (Degree Program)
- **Purpose**: Academic degree program (e.g. Diploma in Computer Engineering, B.Tech CSE).
- **Key Fields**:
  - `collegeId`: ObjectId (ref: `College`)
  - `departmentId`: ObjectId (ref: `Department`)
  - `name`: String (e.g. "Diploma in Computer Engineering")
  - `code`: String (e.g. "DCME-2026")
  - `durationYears`: Number (e.g. 3)
  - `progressionType`: String enum (`'YEAR_SEMESTER'`, `'YEAR_ONLY'`)
  - `status`: String enum (`'active'`, `'inactive'`)
- **Indexes**: `{ collegeId: 1, departmentId: 1, code: 1 }` (unique compound)

### 2.4 `AcademicYear` (Operational Calendar Cycle)
- **Purpose**: The institutional academic year governing term enrollments.
- **Key Fields**:
  - `collegeId`: ObjectId (ref: `College`)
  - `name`: String (e.g. "2025–2026")
  - `startDate`: Date
  - `endDate`: Date
  - `isCurrent`: Boolean (Flag denoting currently active academic year)
  - `status`: String enum (`'upcoming'`, `'active'`, `'completed'`, `'archived'`)
- **Indexes**: `{ collegeId: 1, name: 1 }` (unique compound), `{ collegeId: 1, isCurrent: 1 }`

### 2.5 `Semester` (Term of Study)
- **Purpose**: Chronological academic interval within a course.
- **Key Fields**:
  - `collegeId`: ObjectId (ref: `College`)
  - `departmentId`: ObjectId (ref: `Department`)
  - `courseId`: ObjectId (ref: `Course`)
  - `academicYearId`: ObjectId (ref: `AcademicYear`)
  - `name`: String (e.g. "Semester 5")
  - `number`: Number (1 to 12)
  - `startDate`: Date, `endDate`: Date
  - `status`: String enum (`'upcoming'`, `'active'`, `'completed'`, `'archived'`)
- **Indexes**: `{ collegeId: 1, courseId: 1, academicYearId: 1, number: 1 }` (unique compound)

### 2.6 `Section` (Class Cohort Container)
- **Purpose**: Operational student cohort container for timetable scheduling and attendance.
- **Key Fields**:
  - `collegeId`: ObjectId (ref: `College`)
  - `departmentId`: ObjectId (ref: `Department`)
  - `courseId`: ObjectId (ref: `Course`)
  - `semesterId`: ObjectId (ref: `Semester`)
  - `academicYearId`: ObjectId (ref: `AcademicYear`)
  - `name`: String (e.g. "Section A", "CSE-3A")
  - `capacity`: Number (Optional cohort limit)
  - `status`: String enum (`'active'`, `'inactive'`)
- **Indexes**: `{ collegeId: 1, semesterId: 1, name: 1 }` (unique compound)

### 2.7 `Subject` (Curricular Unit)
- **Purpose**: Curricular syllabus paper taught within a semester.
- **Key Fields**:
  - `collegeId`: ObjectId (ref: `College`)
  - `departmentId`: ObjectId (ref: `Department`)
  - `semesterId`: ObjectId (ref: `Semester`)
  - `courseId`: ObjectId (ref: `Course`, optional)
  - `name`: String (e.g. "Operating Systems")
  - `code`: String (e.g. "CS501")
  - `type`: String enum (`'Theory'`, `'Practical'`, `'Elective'`)
  - `credits`: Number
  - `status`: String enum (`'active'`, `'inactive'`)
- **Indexes**: `{ collegeId: 1, semesterId: 1, code: 1 }` (unique compound)

---

## 3. Identity, People & Teaching Authorization

### 3.1 `User` (Authentication & Account Record)
- **Key Fields**:
  - `_id`: ObjectId
  - `instituteId`: String (Unique business ID)
  - `name`: String
  - `email`: String (Unique, lowercase)
  - `phone`: String (Optional)
  - `passwordHash`: String (Bcrypt salt rounds 10)
  - `role`: String enum (`'SUPER_ADMIN'`, `'COLLEGE_ADMIN'`, `'HOD'`, `'FACULTY'`, `'STUDENT'`)
  - `collegeId`: ObjectId (ref: `College`)
  - `departmentId`: ObjectId (ref: `Department`, optional)
  - `accountStatus`: String enum (`'ACTIVE'`, `'PENDING'`, `'SUSPENDED'`, `'INACTIVE'`)
  - `activationStatus`: String enum (`'PENDING_ACTIVATION'`, `'ACTIVATED'`)
  - `profilePictureUrl`: String
  - `lastLoginAt`: Date
- **Indexes**: `{ instituteId: 1 }` (unique), `{ email: 1 }` (unique), `{ collegeId: 1, role: 1 }`

### 3.2 `FacultyAssignment` (Authoritative Teaching Matrix)
- **Purpose**: Authoritative context binding a faculty member to teach a subject in a section. Required for attendance roll-call and gradebook write permissions.
- **Key Fields**:
  - `collegeId`: ObjectId (ref: `College`)
  - `departmentId`: ObjectId (ref: `Department`)
  - `facultyId`: ObjectId (ref: `Faculty`)
  - `courseId`: ObjectId (ref: `Course`)
  - `semesterId`: ObjectId (ref: `Semester`)
  - `sectionId`: ObjectId (ref: `Section`, optional if institution does not use sections)
  - `subjectId`: ObjectId (ref: `Subject`)
  - `academicYearId`: ObjectId (ref: `AcademicYear`)
  - `assignmentType`: String enum (`'PRIMARY'`, `'SECONDARY'`, `'GUEST'`)
  - `status`: String enum (`'active'`, `'inactive'`)
- **Indexes**: `{ collegeId: 1, facultyId: 1, subjectId: 1, sectionId: 1, academicYearId: 1 }` (unique compound)

### 3.3 `StudentEnrollment` (Term Participation Record)
- **Purpose**: Binds a student to a specific section and semester for an academic year.
- **Key Fields**:
  - `collegeId`: ObjectId (ref: `College`)
  - `studentId`: ObjectId (ref: `Student`)
  - `departmentId`: ObjectId (ref: `Department`)
  - `courseId`: ObjectId (ref: `Course`)
  - `academicYearId`: ObjectId (ref: `AcademicYear`)
  - `semesterId`: ObjectId (ref: `Semester`)
  - `sectionId`: ObjectId (ref: `Section`)
  - `status`: String enum (`'active'`, `'completed'`, `'transferred'`, `'withdrawn'`)
  - `enrollmentDate`: Date
- **Indexes**: `{ collegeId: 1, studentId: 1, semesterId: 1, sectionId: 1 }` (unique compound)

---

## 4. Timetable & Daily Schedule Matrix

### 4.1 `Timetable`
- **Purpose**: Authoritative weekly schedule matrix for a section.
- **Key Fields**:
  - `collegeId`: ObjectId (ref: `College`)
  - `departmentId`: ObjectId (ref: `Department`)
  - `sectionId`: ObjectId (ref: `Section`)
  - `semesterId`: ObjectId (ref: `Semester`)
  - `academicYearId`: ObjectId (ref: `AcademicYear`)
  - `status`: String enum (`'draft'`, `'published'`, `'archived'`)
  - `timingMode`: String enum (`'PERIOD_BASED'`, `'TIME_BASED'`)
  - `periods`: Array of period definitions (periodNumber, startTime, endTime)
  - `entries`: Array of embedded `TimetableGridEntry` objects:
    - `day`: String enum (`'MONDAY'`, `'TUESDAY'`, `'WEDNESDAY'`, `'THURSDAY'`, `'FRIDAY'`, `'SATURDAY'`)
    - `periodNumber`: Number
    - `startTime`: String ("09:00"), `endTime`: String ("10:00")
    - `subjectId`: ObjectId (ref: `Subject`)
    - `facultyId`: ObjectId (ref: `Faculty`)
    - `facultyAssignmentId`: ObjectId (ref: `FacultyAssignment`)
    - `roomId`: ObjectId (ref: `Room`, optional)
    - `sessionType`: String enum (`'THEORY'`, `'LAB'`, `'TUTORIAL'`)
- **Indexes**: `{ collegeId: 1, sectionId: 1, academicYearId: 1, status: 1 }`

### 4.2 `TeacherSubstitution`
- **Purpose**: Temporary substitution of a faculty member for a scheduled class.
- **Key Fields**:
  - `collegeId`: ObjectId (ref: `College`)
  - `timetableId`: ObjectId (ref: `Timetable`)
  - `timetableEntryId`: ObjectId
  - `date`: Date
  - `originalFacultyId`: ObjectId (ref: `Faculty`)
  - `substituteFacultyId`: ObjectId (ref: `Faculty`)
  - `status`: String enum (`'PENDING'`, `'CONFIRMED'`, `'CANCELLED'`)
  - `reason`: String
- **Indexes**: `{ collegeId: 1, date: 1, originalFacultyId: 1 }`

---

## 5. Attendance & Roll Call Engine

### 5.1 `AttendanceSession`
- **Purpose**: Individual teaching instance for roll call roll.
- **Key Fields**:
  - `collegeId`: ObjectId (ref: `College`)
  - `sectionId`: ObjectId (ref: `Section`)
  - `subjectId`: ObjectId (ref: `Subject`)
  - `facultyId`: ObjectId (ref: `Faculty`)
  - `facultyAssignmentId`: ObjectId (ref: `FacultyAssignment`)
  - `date`: Date (Midnight normalized)
  - `timeSlot`: String ("09:00 - 10:00")
  - `status`: String enum (`'PENDING'`, `'SUBMITTED'`, `'LOCKED'`)
  - `totalStudents`: Number, `presentCount`: Number, `absentCount`: Number
- **Indexes**: `{ collegeId: 1, sectionId: 1, subjectId: 1, date: 1, timeSlot: 1 }` (unique compound)

### 5.2 `AttendanceRecord`
- **Purpose**: Per-student attendance marking entry.
- **Key Fields**:
  - `collegeId`: ObjectId (ref: `College`)
  - `sessionId`: ObjectId (ref: `AttendanceSession`)
  - `studentId`: ObjectId (ref: `Student`)
  - `sectionId`: ObjectId (ref: `Section`)
  - `subjectId`: ObjectId (ref: `Subject`)
  - `date`: Date
  - `status`: String enum (`'PRESENT'`, `'ABSENT'`, `'LATE'`, `'EXCUSED'`, `'ON_DUTY'`)
  - `remarks`: String (Optional justification for absence/OD)
- **Indexes**: `{ collegeId: 1, sessionId: 1, studentId: 1 }` (unique compound), `{ collegeId: 1, studentId: 1, date: 1 }`

---

## 6. Assessments, Assignments & Academic Records

### 6.1 `InternalAssessment` & `AssessmentMark`
- **Purpose**: Term assessment scorebook (CIA 1, CIA 2, Model exams).
- **Key Fields (`InternalAssessment`)**:
  - `collegeId`: ObjectId
  - `sectionId`: ObjectId, `subjectId`: ObjectId, `facultyId`: ObjectId
  - `name`: String (e.g. "Internal Assessment 1")
  - `maxMarks`: Number (e.g. 50)
  - `weightage`: Number (e.g. 20%)
  - `status`: String enum (`'DRAFT'`, `'PUBLISHED'`, `'LOCKED'`)
- **Key Fields (`AssessmentMark`)**:
  - `assessmentId`: ObjectId (ref: `InternalAssessment`)
  - `studentId`: ObjectId (ref: `Student`)
  - `marksObtained`: Number
  - `isAbsent`: Boolean

### 6.2 `Assignment` & `AssignmentSubmission`
- **Purpose**: Coursework publishing, digital file submissions, and grading.
- **Key Fields (`Assignment`)**:
  - `collegeId`: ObjectId, `sectionId`: ObjectId, `subjectId`: ObjectId
  - `facultyId`: ObjectId
  - `title`: String, `description`: String, `dueDate`: Date, `maxScore`: Number
  - `attachmentUrls`: Array of Strings (ImageKit)
- **Key Fields (`AssignmentSubmission`)**:
  - `assignmentId`: ObjectId
  - `studentId`: ObjectId
  - `submittedAt`: Date
  - `fileUrls`: Array of Strings
  - `score`: Number, `feedback`: String

---

## 7. Campus Communications, Materials & Workflows

### 7.1 `Note` (Lecture Study Materials)
- **Key Fields**:
  - `collegeId`: ObjectId, `departmentId`: ObjectId, `subjectId`: ObjectId
  - `uploadedBy`: ObjectId (ref: `User`)
  - `title`: String, `description`: String
  - `fileUrl`: String (ImageKit CDN URL)
  - `fileType`: String (PDF, PPT, DOCX), `fileSizeBytes`: Number
- **Indexes**: `{ collegeId: 1, subjectId: 1 }`

### 7.2 `RequestModel` (Formal Campus Approvals)
- **Key Fields**:
  - `collegeId`: ObjectId
  - `requesterId`: ObjectId (ref: `User`)
  - `requestType`: String enum (`'LEAVE'`, `'ON_DUTY'`, `'GRIEVANCE'`, `'BONAFIDE'`)
  - `reason`: String, `startDate`: Date, `endDate`: Date
  - `currentStatus`: String enum (`'PENDING'`, `'APPROVED'`, `'REJECTED'`, `'CANCELLED'`)
  - `timeline`: Array of approval steps with reviewerId, action, comments, timestamp
- **Indexes**: `{ collegeId: 1, requesterId: 1, currentStatus: 1 }`

### 7.3 `Announcement` (Broadcast Notices)
- **Key Fields**:
  - `collegeId`: ObjectId, `departmentId`: ObjectId (optional)
  - `title`: String, `content`: String
  - `audienceScope`: String enum (`'COLLEGE'`, `'DEPARTMENT'`, `'SECTION'`, `'ROLE'`)
  - `targetRoles`: Array of Strings (`'FACULTY'`, `'STUDENT'`)
  - `priority`: String enum (`'NORMAL'`, `'URGENT'`, `'CRITICAL'`)
  - `expiresAt`: Date
- **Indexes**: `{ collegeId: 1, audienceScope: 1, expiresAt: 1 }`

---

## 8. Security & Session Persistence

### 8.1 `AuthSession`
- **Purpose**: Active refresh token tracking and remote session termination.
- **Key Fields**:
  - `userId`: ObjectId (ref: `User`)
  - `refreshTokenHash`: String
  - `deviceInfo`: String, `ipAddress`: String
  - `expiresAt`: Date
  - `isRevoked`: Boolean, `revokedAt`: Date
- **Indexes**: `{ userId: 1, isRevoked: 1 }`, `{ expiresAt: 1 }` (TTL index)

### 8.2 `AuditLog`
- **Purpose**: Immutable administrative audit ledger.
- **Key Fields**:
  - `collegeId`: ObjectId
  - `actorId`: ObjectId (ref: `User`)
  - `action`: String (e.g. "UPDATE_STUDENT_MARKS", "PUBLISH_TIMETABLE")
  - `entityType`: String, `entityId`: ObjectId
  - `beforeState`: Mixed JSON, `afterState`: Mixed JSON
  - `ipAddress`: String, `timestamp`: Date
- **Indexes**: `{ collegeId: 1, timestamp: -1 }`, `{ entityType: 1, entityId: 1 }`

---

## 9. Representative Synthetic Seed Schema

The synthetic dataset generator (`backend/src/scripts/seed-svgp-demo.ts`) instantiates the entire entity hierarchy for testing:

```text
SVGP Campus (College: 'SVGP')
├── CME Department (Computer Engineering)
│   ├── DCME-2026 (Course)
│   │   ├── Academic Year: 2025–2026
│   │   │   ├── Semester 5 (Term 5)
│   │   │   │   ├── Section A (Class cohort)
│   │   │   │   │   ├── Enrolled Students: 30 (student1@acadex.com ... student30@acadex.com)
│   │   │   │   │   ├── Subjects: CS501 (OS), CS502 (DBMS), CS503 (CN)
│   │   │   │   │   ├── Faculty Assignments: faculty.cse@acadex.com (CS501)
│   │   │   │   │   ├── Timetable: 6 days, 7 periods/day
│   │   │   │   │   ├── Attendance: 4 weeks synthetic roll calls (91% avg)
│   │   │   │   │   └── Assessments: CIA 1 Marks recorded
```
