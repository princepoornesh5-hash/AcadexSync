# AcadexSync System Architecture Specification

This document details the architectural topology of **AcadexSync**, spanning the client-side presentation framework, the multi-tenant Node.js application server, MongoDB Atlas data layer, WebSocket event streaming, and hybrid artificial intelligence services.

---

## 1. System Topology Overview

```mermaid
graph TD
    subgraph ClientLayer["Frontend Client Layer (Flutter 3.x)"]
        FlutterApp["AcadexSync Mobile / Web Client"]
        RiverpodState["Riverpod Reactive State Store"]
        DioClient["Dio HTTP Client (Auto 401 Refresh)"]
        WSClient["WebSocket Client Channel (/ws)"]
    end

    subgraph GatewayLayer["API Gateway & Node.js Application Server"]
        ExpressApp["Express.js 4.21 Application Server"]
        AuthMW["Authentication Boundary (HMAC-SHA256 JWT)"]
        TenantMW["Tenant Isolation (requireCollegeScope)"]
        RoleMW["Hierarchical RBAC (5 Roles)"]
        WSServer["WebSocket Server (RFC 6455)"]
        ChangeStreamMgr["MongoDB Change Stream Manager"]
    end

    subgraph ServiceLayer["Domain Services Layer"]
        AuthService["Auth & Session Service"]
        AcademicService["Academic Hierarchy Service"]
        AttendanceService["Attendance & Session Engine"]
        TimetableService["Timetable & Conflict Engine"]
        AiNodeService["Gemini AI Service (@google/genai)"]
        FcmService["FCM Push Notification Service"]
        ImageKitService["ImageKit Storage Service"]
    end

    subgraph DataLayer["Persistence & Cloud Infrastructure"]
        AtlasDB[("MongoDB Atlas Cloud Database<br/>(48 Mongoose Schemas)")]
        ImageKitCDN["ImageKit Cloud CDN"]
        FirebaseCloud["Firebase Cloud Messaging (FCM)"]
        GeminiAPI["Google Gemini 2.5 Flash API"]
    end

    subgraph MicroserviceLayer["Specialized Python Microservices"]
        FastAPIApp["Campus AI Service (FastAPI)"]
        RAGService["FAISS Vector RAG Engine"]
        TimetableSolver["Constraint Timetable Solver"]
    end

    FlutterApp --> RiverpodState
    RiverpodState --> DioClient
    RiverpodState --> WSClient

    DioClient -->|REST /api/v1/*| ExpressApp
    WSClient -->|Bi-directional Events| WSServer

    ExpressApp --> AuthMW
    AuthMW --> TenantMW
    TenantMW --> RoleMW
    RoleMW --> ServiceLayer

    WSServer <--> ChangeStreamMgr
    ChangeStreamMgr <--> AtlasDB

    ServiceLayer --> AtlasDB
    FcmService --> FirebaseCloud
    ImageKitService --> ImageKitCDN
    AiNodeService --> GeminiAPI

    FastAPIApp --> RAGService
    FastAPIApp --> TimetableSolver
```

---

## 2. Frontend Architectural Design

The AcadexSync client application is constructed using **Flutter 3.x** and Dart, adhering to a reactive, decoupled domain architecture.

### 2.1 State Management via Riverpod 2.6
- **Predictable Unidirectional Data Flow**: State is managed via `AsyncNotifierProvider` and `StateNotifierProvider` structures, isolating presentation widgets from business computation.
- **Granular Reactivity**: Widgets selectively watch sub-properties of state using `.select()`, eliminating wasteful full-tree rebuilds.
- **Live Cache Invalidation**: Realtime WebSocket notifications trigger `ref.invalidate()` on specific entity providers (e.g., `studentAttendanceProvider`, `announcementsProvider`), causing seamless in-place UI refreshes.

### 2.2 Network Transport & Session Healing
- **Platform-Aware Host Resolution**: `ApiClient` resolves target host addresses dynamically:
  - Android Emulator: `10.0.2.2:5050`
  - Web / Desktop / iOS Simulator: `localhost:5050`
  - Production Release: `https://acadex-backend-main.onrender.com/api/v1`
- **Transparent 401 Refresh Interceptor**: When an access token expires:
  1. The outgoing request receives an HTTP 401 Unauthorized.
  2. The Dio interceptor captures the failure, queues concurrent requests, and calls `/api/v1/auth/refresh`.
  3. Upon receiving a fresh access token, it updates `flutter_secure_storage` and retries the original request seamlessly.
- **Tenancy Context Epoch Protection**: Every request includes an `X-Workspace-Epoch` header. If a user switches institutions, responses from prior requests are discarded via `StaleWorkspaceResponseException`.

---

## 3. Backend Architectural Design

The backend is engineered on **Node.js + TypeScript** using Express 4.21 and Mongoose 8.9 ODM.

### 3.1 Pipeline Processing & Layered Isolation
Every incoming HTTP request passes through a sequence of protective middleware boundaries:
1. **Security Headers**: `helmet` configures restrictive Content Security Policies, HSTS, XSS filters, and frameguard protections.
2. **Rate Limiting**: `rateLimiter.middleware.ts` enforces tiered request limits per IP/user across general, authentication, upload, and AI routes.
3. **Authentication Boundary**: `authenticateRequest` verifies HMAC-SHA256 bearer tokens and validates that the token has not been revoked in `AuthSession`.
4. **Multi-Tenancy Guard**: `requireCollegeScope` verifies that the caller has an active association with the target `collegeId`. Non-super-admins cannot target foreign institutions.
5. **Role-Based Access Control**: `requireRoles` enforces privilege ceilings (`SUPER_ADMIN` > `COLLEGE_ADMIN` > `HOD` > `FACULTY` > `STUDENT`).
6. **Input Validation**: `validateBody`, `validateQuery`, `validateParams` execute strict Zod schemas, returning detailed validation errors before controller invocation.

### 3.2 Decoupled Institutional Identity Model
AcadexSync enforces a strict separation between technical database identity and human business identity:

```mermaid
graph TD
    UserDoc["User Record in MongoDB Atlas"]
    TechnicalKey["_id: ObjectId<br/>(Immutable Database Relational Key)"]
    BusinessKey["instituteId: String<br/>(Mutable Institutional Identifier, e.g. 'CSE-2026-042')"]

    UserDoc --> TechnicalKey
    UserDoc --> BusinessKey

    TechnicalKey --> AttendanceRecords["Attendance Sessions & Records"]
    TechnicalKey --> Timetables["Timetable Grid Entries"]
    TechnicalKey --> Marks["Internal Assessment Ledgers"]
    TechnicalKey --> Notes["Uploaded Study Materials"]

    BusinessKey --> SearchUI["Human Search & Directory Display"]
    BusinessKey --> RosterPrint["Printed Transcripts & ID Cards"]
```

- **Data Integrity Guarantee**: If an administrator edits a student's roll number or department registration (`instituteId`), no foreign key links break because all operational collections reference the immutable MongoDB `_id`.

---

## 4. Realtime Streaming & Change Detection

AcadexSync implements low-latency push updates using RFC 6455 WebSockets coupled with MongoDB Change Streams:

```mermaid
sequenceDiagram
    autonumber
    actor Faculty as Faculty Client
    participant Express as Express REST API
    participant Mongo as MongoDB Atlas Cluster
    participant ChangeStream as ChangeStream Manager
    participant WS as WebSocket Server
    actor Student as Student Client

    Faculty->>Express: POST /api/v1/attendance/sessions (Roll Call Submit)
    Express->>Mongo: Insert AttendanceRecord & Update Session
    Mongo-->>ChangeStream: Change Stream Event (Insert/Update)
    ChangeStream->>WS: Emit 'ATTENDANCE_MARKED' payload
    WS->>Student: WebSocket Frame { type: 'ATTENDANCE_MARKED', sectionId: '...' }
    Student->>Student: Invalidate 'studentAttendanceProvider'
    Student->>Express: GET /api/v1/attendance/my-summary (Silent Re-fetch)
```

---

## 5. Artificial Intelligence Architecture

AcadexSync utilizes a hybrid AI architecture designed for performance, security, and context-aware student support:

```mermaid
sequenceDiagram
    autonumber
    actor User as Authenticated Student / Faculty
    participant Client as Flutter Client
    participant Route as Express AI Route (/api/v1/ai/chat)
    participant RateLimit as AI Rate Limiter (30 req/min)
    participant AIService as Backend AiService
    participant Gemini as Google Gemini 2.5 Flash API

    User->>Client: Enters question in AI Assistant
    Client->>Route: POST /api/v1/ai/chat { message: "What classes do I have today?" }
    Route->>RateLimit: Check rate quota
    RateLimit->>AIService: Forward validated query & session user context
    Note over AIService: Build System Instruction:<br/>- User Name & Role<br/>- Tenant College & Dept<br/>- Strict Read-Only Constraint<br/>- Anti-Prompt-Injection Rules
    AIService->>Gemini: generateContent({ model: 'gemini-2.5-flash', contents })
    Gemini-->>AIService: Return Markdown Answer
    AIService-->>Route: Formatted response
    Route-->>Client: 200 OK { success: true, answer: "..." }
    Client->>User: Renders formatted Markdown in Chat View
```

### Security Safeguards Implemented in `AiService`
1. **Strict Read-Only Sandboxing**: The system prompt explicitly instructs the LLM that it cannot perform database modifications, grade updates, or attendance alterations.
2. **Context Injection without Secrets**: The assistant receives session-derived identity metadata (`name`, `role`, `college`, `department`) but zero server secrets or database connection strings.
3. **Upstream Timeout Guards**: Requests are wrapped in a 15-second timeout race (`AI_TIMEOUT_MS`), preventing server thread starvation.
4. **Sanitized Error Logging**: In the event of upstream API errors, user prompts and identifiable tokens are scrubbed from log files.
