# AcadexSync Project Structure & Directory Taxonomy

This document outlines the organization of the **AcadexSync** codebase, providing architectural rationale for the directory layout, module boundaries, and file placement.

---

## 1. High-Level Directory Overview

```text
AcadexSync_Documentation_Source/
├── frontend/lib/               # Flutter client application (Dart)
│   ├── app/                    # Routing, global themes, and shell layouts
│   ├── core/                   # Shared infrastructure: network, design system, errors
│   └── features/               # 22 self-contained vertical feature domains
├── backend/
│   ├── src/                    # Node.js/TypeScript backend (Express + Mongoose)
│   │   ├── config/             # Zod-validated environment configuration
│   │   ├── constants/          # System enums, roles, statuses, and boundaries
│   │   ├── controllers/        # 33 REST API controllers
│   │   ├── db/                 # MongoDB Atlas connection lifecycle
│   │   ├── events/             # Domain event listeners (e.g. request notifications)
│   │   ├── middleware/         # Auth, Tenant isolation, RBAC, Rate limiting
│   │   ├── models/             # 48 Mongoose schema models and indexes
│   │   ├── realtime/           # WebSocket server & MongoDB Change Streams
│   │   ├── reports/            # PDF and spreadsheet generation engines
│   │   ├── routes/             # REST route registration (v1 index & subrouters)
│   │   ├── scripts/            # Database seed scripts and admin bootstrap
│   │   ├── services/           # 31 domain business logic services
│   │   ├── storage/            # ImageKit media integration
│   │   ├── types/              # TypeScript declarations and Express extensions
│   │   ├── utils/              # API helpers, Logger, Token crypto, Session utils
│   │   └── validations/        # Zod validation schemas for all API payloads
│   └── ai_service/             # Python FastAPI microservice (RAG & Timetable solver)
├── tests/
│   ├── backend/                # Jest integration and unit test suites (97 files)
│   └── frontend/               # Flutter widget, unit, and integration tests (181 files)
├── configuration/              # Build definitions, package manifests, and .env templates
└── docs/                       # Baseline specifications and verification reports
```

---

## 2. Frontend Source Architecture (`frontend/lib/`)

The Flutter application follows a clean feature-first architecture with Riverpod for reactive state management, Dio for network transport, and GoRouter for declarative routing.

### `app/` (Application Shell & Infrastructure)
- **`app/router/app_router.dart`**: Defines GoRouter configuration containing 131 route definitions, path constants, authentication redirect guards, and role-based shell navigation wrappers (`ShellWrapper`).
- **`app/theme/app_theme.dart`**: Unified design system tokens, adaptive color palettes (dark mode primary), typography scales via Google Fonts (Inter / Outfit), and responsive layout breakpoints.

### `core/` (Cross-Cutting Infrastructure)
- **`core/network/api_client.dart`**: Configures the primary `Dio` HTTP client with:
  - Base URL resolution with platform-aware host fallback (`10.0.2.2` for Android emulators, `localhost` for web/desktop).
  - Automated JWT 401 interceptor that requests a refreshed token via `/api/v1/auth/refresh` and transparently retries failed requests.
  - Workspace epoch tracking (`X-Workspace-Epoch`) to discard responses from obsolete tenancy contexts.
- **`core/realtime/`**: Native WebSocket client (`realtime_client.dart`) and Riverpod event bus invalidating cached providers upon server push events.
- **`core/presentation/`**: Design system widget library including `AcadexButton`, `AcadexCard`, `AcadexBadge`, `AcadexTextField`, `AcadexModal`, `AcadexDataGrid`, and `AcadexPageContainer`.
- **`core/observability/`**: Structured client-side logger (`logger.dart`) capturing diagnostic breadcrumbs.
- **`core/errors/`**: Standardized domain exceptions (`api_exception.dart`, `app_error.dart`).
- **`core/services/`**: ImageKit direct media uploader (`imagekit_uploader.dart`).

### `features/` (22 Feature Domains)
Each feature domain encapsulates its domain models, repository contracts, live API implementations, Riverpod state notifiers, and UI presentation screens:

```text
features/
├── academic_records/           # Semester transcript ledger and subject marks
├── academic_results/           # University examination results & grade publications
├── academic_structure/         # College -> Dept -> Course -> AY -> Term -> Section -> Subject
├── achievements/               # Student awards and extracurricular credentials
├── ai_assistant/               # Conversational Gemini assistant UI, sidebar, and composer
├── analytics/                  # Departmental pass percentage and performance dashboards
├── assessments/                # Continuous internal assessment (CIA) markbooks
├── assignments/                # Coursework publication, deadlines, and file submissions
├── attendance/                 # Timetable roll calls, session integrity, and alert thresholds
├── auth/                       # Login, 8-char invitation activation, OTP password reset
├── calendar/                   # Academic calendar, institutional events, holiday overrides
├── certificates/               # Bonafide and academic certificate generation
├── dashboard/                  # Role-specific executive home dashboards (5 roles)
├── institution_config/         # Terminology customization and academic hierarchy toggles
├── notes/                      # Lecture study materials with ImageKit CDN delivery
├── notifications/              # Direct notification center and FCM push preference toggles
├── practicals/                 # Laboratory experiments, apparatus records, and viva scores
├── profile/                    # User identity cards, contact settings, password change
├── reports/                    # Tabular export generation (Attendance, Roster, Marks)
├── requests/                   # Formal leave, OD, and grievance approval workflows
├── search/                     # Global campus search across people, subjects, and records
├── settings/                   # Theme toggle, workspace switcher, and cache management
├── storage/                    # Cloud media file browser and attachment picker
└── users/                      # User directory, role provisioning, and account status toggles
```

---

## 3. Backend Source Architecture (`backend/src/`)

The Node.js backend is built on TypeScript, Express 4.21, and Mongoose 8.9, delivering a multi-tenant, role-governed REST API and WebSocket gateway.

### Entry Point & Application Bootstrap
- **`server.ts`**: Instantiates the Node.js HTTP server, mounts the `app` instance, binds the RFC 6455 WebSocket server (`realtimeServer.attachToServer`), and connects to MongoDB Atlas.
- **`app.ts`**: Configures security middleware (`helmet` with strict CSP, parameterized `cors`), HTTP logging (`morgan`), body parsers (`express.json({ limit: '10mb' })`), rate limiting, API routes under `/api/v1`, and the centralized error handling pipeline.
- **`config/env.ts`**: Strict Zod environment schema verifying critical parameters (`MONGODB_URI`, `JWT_SECRET`, `IMAGEKIT_*`, `GEMINI_API_KEY`) at server boot.

### Key Backend Subsystems
- **`models/` (48 Domain Schemas)**: Authoritative Mongoose schemas enforcing compound unique indexes, foreign key relationships, and lifecycle status fields.
- **`middleware/`**:
  - `auth.middleware.ts`: Verifies HMAC-SHA256 JWT Bearer tokens and checks active session validity in `AuthSession`.
  - `tenant.middleware.ts`: `requireCollegeScope` extracts `collegeId` and blocks cross-tenant unauthorized data access.
  - `role.middleware.ts`: `requireRoles` and `requireMinRole` enforce the 5-tier role hierarchy.
  - `validate.middleware.ts`: Validates request body, query, and params against Zod schemas before hitting controllers.
  - `rateLimiter.middleware.ts`: Configurable window-based rate limiting per IP and user identity.
- **`services/` (31 Business Services)**: Encapsulates pure business logic. Notable services include:
  - `auth.service.ts`: Secure login, bcrypt hashing, token issuance, password reset OTP.
  - `teachingAuthorization.service.ts`: Validates that a faculty member is assigned to teach a subject/section before allowing attendance, assignments, or marks entries.
  - `attendance.service.ts`: Roll call processing, session idempotency, attendance aggregation, and notification triggers.
  - `timetable.service.ts`: Weekly schedule matrix validation, conflict detection (faculty/room double-booking).
  - `ai.service.ts`: Google Gen AI (`@google/genai`) Gemini 2.5 Flash assistant with session context injection and read-only security guards.
  - `fcm.service.ts`: Firebase Cloud Messaging multicast push dispatch via Firebase Admin SDK.
- **`realtime/`**:
  - `realtime.server.ts`: Native WebSocket server supporting authenticated client connection, room subscriptions (by college, department, user), and message delivery.
  - `changeStream.manager.ts`: Listens to MongoDB Atlas Change Streams and automatically broadcasts updates to connected clients.
- **`scripts/`**:
  - `seed-svgp-demo.ts`: Comprehensive synthetic demo seeder populating a complete technical campus (SVGP) with departments, courses, students, faculty, timetables, and attendance history.
  - `create-super-admin.ts`: CLI utility for bootstrapping initial platform administrators.

---

## 4. AI Microservice Architecture (`backend/ai_service/`)

A dedicated Python FastAPI microservice provides specialized machine learning and combinatorial optimization services:
- **`app/main.py`**: FastAPI entry point exposing `/health`, `/api/v1/ai/chat`, and `/api/v1/ai/generate-timetable`.
- **`app/services/rag_chatbot.py`**: Retrieval-Augmented Generation pipeline using sentence embeddings and vector similarity for institutional query answering.
- **`app/services/timetable_solver.py`**: Constraint-satisfaction algorithm solving multi-variable room, faculty, and timeslot scheduling conflicts.

---

## 5. Tests Architecture (`tests/`)

- **`tests/backend/`**:
  - `unit/`: Isolated logic validation for OTPs, passwords, identifier formatting, Zod schemas, ImageKit storage client, and rate limiting.
  - `integration/`: Full end-to-end API tests using Supertest and in-memory MongoDB (`mongodb-memory-server`) covering Auth, Academic Hierarchy, Attendance Session Integrity, Faculty Assignments, Timetables, and AI Chat endpoints.
  - `helpers/auth.helper.ts`: Synthetic token issuance and test user bootstrapping.
- **`tests/frontend/`**:
  - Unit tests for Riverpod domain state notifiers.
  - Widget tests verifying UI rendering, role permissions, and empty states.
  - Integration tests validating multi-step flows (Login -> Shell -> Attendance Marking -> Session Verification).
